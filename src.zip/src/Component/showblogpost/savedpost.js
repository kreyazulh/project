import React, { useEffect } from 'react';
import  { useContext, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { UserContext } from '../../App';

//import NavBar from '../NavBar/NavBar';


//HERE 
const Savedpost = ({})=> 
{
    
      
  

   
return (
    <div>
        <div>
            <p>
            <input type="submit" value="Save post" className='createpostBtn' />
            { }
            </p>
           </div>
    
    </div>
        );
    };
    
    export default Savedpost;