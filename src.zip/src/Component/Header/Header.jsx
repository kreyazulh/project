import React, { useState } from 'react';
import './Header.css';


const Header = () => {
    
    return (
        <div>
            <div className="header">
                <h1>PROJECT FORNAX</h1>
            </div>
            
        </div>
    );
};

export default Header;