import React from 'react';
import './Footer.css'

const Footer = () => {
    return (
        <div>
            <div className='footer-container'>
                <h4>Team Project Fornax</h4>
                <p> @Copyright Reserved</p>
            </div>
        </div>
    );
};

export default Footer;